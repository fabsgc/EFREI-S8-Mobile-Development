# Assignment 2: Calculator Brain

The goal of this assignment is to push its capabilities a bit further by allowing a “variable” as an input to the Calculator and support Undo.

![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/Assignment%202/calculator.gif)
