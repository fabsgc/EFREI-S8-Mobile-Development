# Assignment 3: Graphing Calculator

The goal of this assignment is to create a graph of the “program” the user has entered which can be zoomed in on and panned around. This app will now work not only on iPhones, but on iPads as well.

![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/Assignment%203/calculator.gif)
