# Assignment 4: Smashtag Mentions

The goal of this assignment is to enhance the Smashtag application that we built in class to give ready-access to hashtags, urls, images and users mentioned in a tweet.

![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/Assignment%204/smashtag.gif)
