# Assignment 6: Animation

The goal of this assignment is to let anyone play the game Breakout.

![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/Assignment%206/breakout.gif)
