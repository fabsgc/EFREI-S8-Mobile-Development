# Assignment 1: Calculator

The goal of this assignment is to recreate the demonstration given in lecture and then make some small enhancements.

![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/Assignment%201/calculator.gif)
