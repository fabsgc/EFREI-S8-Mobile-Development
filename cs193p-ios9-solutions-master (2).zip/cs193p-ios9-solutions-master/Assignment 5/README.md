# Assignment 5: Smashtag Mention Popularity

The goal of this assignment is to enhance the Smashtag application even further to do some analysis on all of the mentions in a search result using Core Data.

![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/Assignment%205/smashtag.gif)
