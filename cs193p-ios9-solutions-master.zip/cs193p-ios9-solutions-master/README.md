# cs193p-ios9-solutions
My solutions to the assignments (6/6) for Stanford's CS193P: Developing iOS 9 Apps with Swift [Spring 2016]

![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/1.gif)
![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/2.gif)
![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/3.gif)

![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/4.gif)
![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/5.gif)
![](https://github.com/linouk23/cs193p-ios9-solutions/blob/master/6.gif)